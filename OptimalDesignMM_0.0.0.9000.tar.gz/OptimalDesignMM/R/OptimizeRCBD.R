
#' Randomly swap pairs of treatments for optimization
#'
#' \code{SwapMethods} randomly selects a block and a pair of treatments, swaps them
#'  and creates a new experimental layout
#'
#' @param matdf an experimental design
#' @param iter number of iterations (number of swaps)
#' @param pairs number of pairs of treatments to be swapped in every iteration
#' @param swapmethod the method to be used. This can be ``within" which is the default (that should be  used for randomized complete block designs) or ``across" or ``any" which should be used for  unbalanced designs
#' @param criteria indicates the optimization criteria to report. It can be "A" for A-Optimal or "D" for D-Optimal.
#' @param Ginv a variance-covariance matrix from pedigree or molecular data
#' @param Rinv an inverse of the error variance-covariance matrix if available
#' @param K a matrix calculated from original dataset
#'
#' @return an improved experimental design
#'
#' @references
#' Mramba, L.K. and Gezan, S.A. (2016), Optimal Randomized Complete Block Designs for Spatially and Genetically Correlated Data using Mixed Models, Journal of Agricultural, Biological and Environmental Statistics, 150, 1-32.
#'
#' @author
#' Lazarus Mramba & Salvador Gezan
#'
#' @examples
#' trt <- 30
#' blocks <- 2; rb <- 5; cb <- 6; Tr <- 10; Tc <- 6
#' VarG <- 0.3; VarE <- 0.7; rhox <- 0.6; rhoy <- 0.6;
#' matdf <- rcbd(blocks,trt,rb,cb,Tr,Tc)
#' Rinv <- Rmatrix(matdf,VarE,rhox,rhoy)
#' Ginv <- Gmatrix(trt,VarG)   # Independent random effects
#' resD <- VarCov.rcbd(matdf,criteria="A",Ginv,Rinv)
#' # K is not provided but calculated
#' resD$OptimScore
#' K <- resD$K
#' resD <- VarCov.rcbd(matdf,criteria="A",Ginv,Rinv,K) # K is provided
#' (InitScore<-resD$OptimScore)
#' (OldScore<-resD$OptimScore)
#' Oldmatdf<-matdf
#' print(OldScore)
#' iter<-100
#' newD = OptimizeRCBD(matdf,iter,pairs=1,swapmethod="within",
#' criteria="A",Ginv,Rinv,K)
#' DesLayout(newD$newDesign, trt, cb, rb, blocks)
#' DesLayout(Oldmatdf, trt, cb, rb, blocks)
#'
#' @export
#' @seealso \code{\link{SwapMethods}}, \code{\link{VarCov.rcbd}}

OptimizeRCBD <- function(matdf,iter=10,pairs=1,swapmethod="within",
                         criteria="A",Ginv=NULL,Rinv=NULL,K=NULL) {
for (i in 1:iter) {
  newmatdf <- SwapMethods(matdf,pairs,swapmethod)
  NewScore <- VarCov.rcbd(newmatdf,criteria,Ginv,Rinv,K)$OptimScore
  if(NewScore < OldScore){
    OldScore <- NewScore
    matdf <- newmatdf
    print(OldScore)
  }
}
  return(list(OptimScore=OldScore,newDesign=matdf))
}
