#' Randomly swap pairs of treatments for optimization
#'
#' \code{SwapMethods} randomly selects a block and a pair of treatments, swaps them
#'  and creates a new experimental layout
#'
#' @param matdf an experimental design
#' @param pairs number of pairs of treatments to be swapped in every iteration
#' @param swapmethod the method to be used. This can be ``within" which is the default (that should be
#' used for randomized complete block designs) or ``across" or ``any" which should be used for
#' unbalanced designs
#'
#' @return an new experimental design with swapped pairs of treatments
#'
#' @references
#' Mramba, L.K. and Gezan, S.A. (2016), Optimal Randomized Complete Block Designs for Spatially and Genetically Correlated Data using Mixed Models, Journal of Agricultural, Biological and Environmental Statistics, 150, 1-32.
#'
#' @author
#' Lazarus Mramba & Salvador Gezan
#'
#' @examples
#' # Example: Regular-grid experiment with independent random effects
#' trt <- 30
#' blocks <- 2; rb <- 5; cb <- 6; Tr <- 10; Tc <- 6
#' matdf <- rcbd(blocks,trt,rb,cb,Tr,Tc)  # Original design
#' DesLayout(matdf,trt,cb,rb,blocks)
#'
#' # Swapping within for a single pair
#' newmatdf <- SwapMethods(matdf,pairs=1,swapmethod="within")
#' DesLayout(newmatdf,trt,cb,rb,blocks)
#'
#' # Swapping within for a 2 pairs
#' newmatdf <- SwapMethods(matdf,pairs=2,swapmethod="within")
#' DesLayout(newmatdf,trt,cb,rb,blocks)
#'
#' # Swapping across for a single pair
#' newmatdf <- SwapMethods(matdf,pairs=1,swapmethod="across")
#' DesLayout(newmatdf,trt,cb,rb,blocks)
#'
#' # Swapping any for 2 pairs
#' newmatdf <- SwapMethods(matdf,pairs=1,swapmethod="any")
#' DesLayout(newmatdf,trt,cb,rb,blocks)
#'
#' @export
#' @seealso \code{\link{DesLayout}}, \code{\link{rcbd}}
#'
#'
SwapMethods <- function(matdf,pairs=1,swapmethod="within") {
  trt <- max(matdf[,"Treatments"])
  gsize <- pairs*2
  stopifnot(gsize %% 2 == 0)
  if(gsize > trt){
    stop("Number of swaps is larger than the number of Treatments")
  }
  # Swaping  any blocks any pairs
  if(swapmethod=="any"){
    list <- c('within','across')
    sel <- sample(list,1)
    swapmethod <- sel
  }
  # Swapping only within a block for any pair
  if(swapmethod=="within"){
    mat <- as.data.frame(matdf, row.names = NULL)
    b1 <- sample(mat$Reps, 1, replace = TRUE)  # Selects a block at random
    g1<- sample(1:length(mat$Reps[mat$Reps==1]),gsize,replace=FALSE)
    gg1 <- mat$Treatments[mat$Reps == b1]
    temp <- gg1
    for (i in seq(1,length(g1),2)) {
      temp[g1[i+1]] <- gg1[g1[i]]
      temp[g1[i]] <- gg1[g1[i+1]]
    }
    mat$Treatments[mat$Reps == b1] <- temp
  }
  # Swaping  across blocks for any pairs
  if(swapmethod=="across"){
    mat <- as.data.frame(matdf, row.names = NULL)
    blks <- sample(unique(mat$Reps),2, replace = FALSE)
    gg1 <- mat$Treatments[mat$Reps == blks[1]]
    gg2 <- mat$Treatments[mat$Reps == blks[2]]
    temp1 <- gg1
    temp2 <- gg2
    g1<- sample(1:length(mat$Reps[mat$Reps==blks[1]]),gsize/2,replace=FALSE)
    g2<- sample(1:length(mat$Reps[mat$Reps==blks[2]]),gsize/2,replace=FALSE)
    for (i in seq(1,length(g1),1)) {
      temp2[g2[i]] <- gg1[g1[i]]
      temp1[g1[i]] <- gg2[g2[i]]
    }
    mat$Treatments[mat$Reps == blks[1]] <- temp1
    mat$Treatments[mat$Reps == blks[2]] <- temp2
  }
  return(mat[order(mat[,"Row"],mat[,"Col"]),])
}
