#' Generates the inverse of the error (spatial or temporal) variance-covariance matrix R
#'
#' \code{Rmatrix} Generates the inverse of the error (spatial or temporal) variance-covariance matrix R based on an autorregressive homogeneous error structure AR1 with or without nugget
#'
#' @import Matrix
#'
#' @param matdf an experimental design (layout) where 'Treatments' is the column of effects of interest
#' @param rhox spatial correlation between experimental units along the rows.
#' @param rhoy spatial correlation between experimental units along the columns.
#' @param VarE variance of the residuals. Default is 1
#' @param nugget spatial nugget error. Default is 0.
#' @param regular a logical statement, if TRUE, a different (slower) algorithm for the AR1 error structure is used
#'
#' @return the inverse of the error variance-covariance matrix for homogeneuos AR1 structure
#'
#' @references
#' Mramba, L.K. and Gezan, S.A. (2016), Generating experimental designs for spatially and genetically correlated data using mixed models, Submitted to Australian and New Zealand Journal of Statistics.
#'
#' @author
#' Lazarus Mramba & Salvador Gezan
#'
#' @examples
#' # Example 1: unimproved Regular-grid RCB designs
#' blocks <- 6; trt <- 9; rb <- 3; cb <- 3; Tr <-6; Tc <- 9
#' matdf <- rcbd(blocks,trt,rb,cb,Tr,Tc)
#'
#' ans1 <- Rmatrix(matdf,VarE=0.9)
#' ans1[1:5,1:5]
#'
#' ans2 <- Rmatrix(matdf,VarE=0.9,rhox=0.6,rhoy=0.6)
#' ans2[1:5,1:5]
#'
#' ans3 <- Rmatrix(matdf,VarE=0.9,rhox=0.6,rhoy=0.6,regular=FALSE)
#' ans3[1:5,1:5]
#'
#' @export
#' @seealso \code{\link{Gmatrix}}, \code{\link{rcbd}}

Rmatrix <- function(matdf,VarE=1,rhox=0,rhoy=0,nugget=0,regular=TRUE) {
  #s2e <- 1-VarG-nugget
  s2e <- VarE
  matdf <- matdf[order(matdf[,"Row"],matdf[,"Col"]),]
  if(rhoy==0 & rhox==0){
    Rinv <- (1/(s2e+nugget))*Matrix::Diagonal(nrow(matdf))
  }
  # Irregular Experiment
  if(regular==FALSE){
    N <- nrow(matdf)
    R <- Matrix::Diagonal(N)
    for(i in 1:(N-1)) {
      x1 <- matdf[,"Col"][i]
      y1 <- matdf[,"Row"][i]
      for (j in (i+1):nrow(matdf)){
        x2 <- matdf[,"Col"][j]
        y2 <- matdf[,"Row"][j]
        R[i,j]<-(rhox^abs(x2 -x1))*(rhoy^abs(y2 -y1))
      }
    }
    R <- R + nugget*Matrix::Diagonal(N)
    R <- as.matrix(round(s2e*R,7))
    R[lower.tri(R)] <- t(R)[lower.tri(R)]
    Rinv <- chol2inv(chol(R))
  }
  # Regular Experiment
  if(regular==TRUE){
    N <- nrow(matdf)
    Tr <- max(matdf[,"Row"])
    Tc <- max(matdf[,"Col"])
    sigx <- Matrix::Diagonal(Tc)
    sigx <- rhox^abs(row(sigx) - col(sigx))
    sigy <- Matrix::Diagonal(Tr)
    sigy <- rhoy^abs(row(sigy) - col(sigy))
    R <- s2e*kronecker(sigy, sigx) + nugget*Matrix::Diagonal(N)
    Rinv <- chol2inv(chol(R))
  }
  Matrix::drop0(Rinv)
}
