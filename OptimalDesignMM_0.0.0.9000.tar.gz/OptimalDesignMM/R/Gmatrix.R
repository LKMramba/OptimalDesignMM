#' Generates the inverse of the random factor variance-covariance matrix G
#'
#' \code{Gmatrix} Generates the inverse of the random factor variance-covariance matrix G. This could also be based on a numerator relationship matrix.
#'
#' @import Matrix
#'
#' @param trt number of  treatments per block
#' @param VarG variance of the random factor. Default is 0.3
#' @param Amat numerator relationship matrix. Its dimension should be trt x trt
#'
#' @return the inverse of the random facotr variance-covariance matrix
#'
#' @references
#' Mramba, L.K. and Gezan, S.A. (2016), Generating experimental designs for spatially and genetically correlated data using mixed models, Submitted to Australian and New Zealand Journal of Statistics.
#'
#' @author
#' Salvador Gezan & Lazarus Mramba
#'
#' @examples
#' # Example 1: G inverse obtained from a pedigree with 30 genotypes
#'
#' data(ped30fs)
#' Amat <- GenA(male=ped30fs[,"male"],female=ped30fs[,"female"])
#' Amat <- as.matrix(Amat[-c(1:5),-c(1:5)])   # Only offspring
#' trt <- 30; VarG <- 1
#' Ginv <- Gmatrix(trt,VarG,Amat)
#' Ginv[1:5,1:5]
#' @export
#'@seealso \code{\link{Rmatrix}}, \code{\link{rcbd}},  \code{\link{GenA}}

Gmatrix <- function(trt,VarG=0.3,Amat=NULL) {

  if(is.null(Amat)) {
    Ginv <- (1/VarG)*Matrix::Diagonal(trt)
  } else {
    G <- VarG*as.matrix(Amat)
    Ginv <- chol2inv(chol(as.matrix(G)))
  }
  return(Ginv=Ginv)
}
