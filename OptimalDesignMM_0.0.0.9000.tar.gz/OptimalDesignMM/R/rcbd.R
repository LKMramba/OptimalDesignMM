#' Generates a Randomized Complete Block Design (not optimized)
#'
#' \code{rcbd} Generates an initial RCB design (not optimized).
#'
#' @param blocks number of blocks (full replicates)
#' @param trt number of  treatments per block
#' @param rb number of rows per block (in the field)
#' @param cb number of columns per block (in the field)
#' @param Tr total number of rows (in the field)
#' @param Tc total number of columns (in the field)
#' @param coord matrix with coordinates (x and y) and blocks for each experimental unit, in the form: Row,Col,Reps
#' @param regular logical statement, if FALSE user has to provide the coordinates and replicate for all experimental units'
#'
#' @return an experimental design in matrix form with 4 columns: Row, Col, Reps, Treatments
#'
#' @references
#' Mramba, L.K. and Gezan, S.A. (2016), Generating experimental designs for spatially and genetically correlated data using mixed models, Submitted to Australian and New Zealand Journal of Statistics.
#'
#' @author
#' Lazarus Mramba & Salvador Gezan
#'
#' @examples
#' ## Example 1: Generates a regular-grid RCB design with 4 blocks and 30 treatments
#' blocks <- 2; trt <- 30
#' rb <- 5; cb <- 6; Tr <- 5; Tc <- 12
#' matdf <- rcbd(blocks,trt,rb,cb,Tr,Tc)
#'
#' ## Example 2: Generates an irregular-grid RCB design with 3 blocks and 9 treatments and plots it.
#' blocks <- 3; trt <- 9;
#' Tr <- 6; Tc <- 6; rb <- 3; cb <- 3
#' Row <- c(rep(1:3,each=3),rep(4:6,each=3),rep(4:6,each=3))  # Row position of exp. units
#' Col <- c(rep(1:3,3),rep(1:3,3),rep(4:6,3)) # Column position of exp. units
#' Reps <- c(rep(1:3,each=9))
#' coord <- cbind(Row,Col,Reps)
#' matdf <- rcbd(blocks,trt,rb,cb,Tr,Tc,coord,regular=FALSE)
#'
#' @export
#' @seealso \code{\link{DesLayout}} for a layout with treatments in string format
#'

rcbd<- function(blocks,trt,rb=0,cb=0,Tr=0,Tc=0,coord=list(),regular=TRUE) {
  trt.list <- c(1:trt)
  trt.list <- as.numeric(as.factor(trt.list))
  Treatments <- c(replicate(blocks, sample(trt.list,trt,replace=FALSE)))
  if(length(coord) > 0 & regular==TRUE){
    stop("Designs has coordinates but it is regular")
  }
  # Dealing with regular trials
  if(regular == TRUE){
  if(blocks == 1){
    Reps <- rep(1:blocks,each=length(unique(trt.list)))
    coord <- cbind(Row=rep(1:Tr,each=Tc),Col=rep(1:Tc,Tr))
    matdf <- cbind(coord,Reps=c(rep(1,trt)),Treatments)
    row.names(matdf) <- NULL
  }
  if(cb == Tc & Tr > rb & regular==TRUE){
    Reps <- rep(1:blocks,each=length(unique(trt.list)))
    coord <- cbind(Row=rep(1:Tr,each=cb),Col=rep(1:Tc,rb))
    matdf <- cbind(coord,Reps,Treatments)
    row.names(matdf) <- NULL
  }
  if(rb == Tr & Tc > cb & regular==TRUE){
    Reps <- rep(1:blocks,each=length(unique(trt.list)))
    Row <- rep(rep(1:Tr,each=cb),Tc/cb)
    Col <- rep(split(1:Tc,cut(seq_along(1:Tc),blocks,labels=FALSE)),each=Tr)
    Col <- unlist(Col)
    coord <- cbind(Row,Col)
    matdf <- cbind(coord,Reps,Treatments)
    row.names(matdf) <- NULL
  }
  if(Tr > rb & Tc > cb & regular==TRUE){
    Reps <- rep(1:blocks,each=length(unique(trt.list)))
    Row <- rep(rep(1:Tr,each=cb),Tc/cb)
    Col <- rep(split(1:Tc,cut(seq_along(1:Tc),Tc/cb,labels=FALSE)),each=Tr)
    Col <- unlist(Col)
    coord <- cbind(Row,Col)
    matdf <- cbind(coord,Reps,Treatments)
    row.names(matdf) <- NULL
  }
  }
  # Dealing with irregular trials
  if(regular==FALSE){
    if(length(coord) == 0){
      stop("No coordinates provided")
    }
    if(abs(nrow(coord) - length(Treatments)) > 0){
      stop("Coordinates provided do not match with size of experiment")
    }
    coord <- coord[order(coord[,3]),]  # Ordering by Reps
    matdf <- cbind(coord,Treatments)
    row.names(matdf)<-NULL
  }
  matdf[order(matdf[,"Row"],matdf[,"Col"]),]
}
