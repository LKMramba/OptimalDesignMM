#' Generate variance-covariance matrices, traces and/or determinants
#'
#' \code{VarCov.rcbd} generates the variance-covariance matrix (information matrix) of treatment effects and calculates traces and/or log(determinants) for a linear mixed model with fixed block effects and random treatemnt effects.
#'
#' @param matdf an experimental design (layout), where 'Treatments' is the column of effects of interest
#' @param criteria indicates the optimization criteria to report. It can be "A" for A-Optimal or "D" for D-Optimal.
#' @param Ginv a variance-covariance matrix from pedigree or molecular data
#' @param Rinv an inverse of the error variance-covariance matrix if available
#' @param K a matrix calculated from original dataset
#'
#' @return either a trace value or log of determinant of the variance-covariance matrix (information matrix) for treatments
#'
#' @references
#' Mramba, L.K. and Gezan, S.A. (2016) Generating experimental designs for spatially and genetically correlated data using mixed models, Submitted to Australian and New Zealand Journal of Statistics.
#'
#' @author
#' Lazarus Mramba & Salvador Gezan
#'
#' @examples
#' # Example 1: Regular-grid experiment with independent random effects
#' trt <- 30
#' blocks <- 2; rb <- 5; cb <- 6; Tr <- 10; Tc <- 6
#' VarG <- 0.3; VarE <- 0.7; rhox <- 0.6; rhoy <- 0.6;
#' matdf <- rcbd(blocks,trt,rb,cb,Tr,Tc)
#' Rinv <- Rmatrix(matdf,VarE,rhox,rhoy)
#' Ginv <- Gmatrix(trt,VarG)   # Independent random effects
#' resD <- VarCov.rcbd(matdf,criteria="A",Ginv,Rinv)  # K is not provided but calculated
#' attributes(resD)
#' resD$OptimScore
#' K <- resD$K
#' resD <- VarCov.rcbd(matdf,criteria="A",Ginv,Rinv,K) # K is provided
#'
#' # Example 2: Regular-grid experiment with 2 blocks and 30 related genotypes (treatments)
#' trt <- 30
#' blocks <- 2; rb <- 5; cb <- 6; Tr <- 10; Tc <- 6
#' VarG <- 0.3; rhox <- 0.6; rhoy <- 0.6;
#' matdf <- rcbd(blocks,trt,rb,cb,Tr,Tc)
#' data(ped30fs)
#' Amat <- GenA(male=ped30fs[,"male"],female=ped30fs[,"female"])
#' Amat <- as.matrix(Amat[-c(1:5),-c(1:5)])
#' Ginv <- Gmatrix(trt,VarG,Amat=Amat)   # Pedigree provided
#' Rinv <- Rmatrix(matdf,VarE,rhox,rhoy)
#' resPed <- VarCov.rcbd(matdf,criteria="A",Ginv,Rinv)  # K is not provided but calculated
#' resPed$OptimScore
#'
#' @export
#' @seealso \code{\link{DesLayout}}, \code{\link{rcbd}}, \code{\link{Gmatrix}}, \code{\link{Rmatrix}}, \code{\link{GenA}}
#'
VarCov.rcbd <- function(matdf,criteria="A",Ginv=NULL,Rinv=NULL,K=NULL) {
  # Checking if Rinv anf Ginv is not provided
  if(is.null(Rinv)){
    stop('Rinv was not provided')
  }
  if(is.null(Ginv)){
    stop('Ginv was not provided')
  }
  # Obtaining Z matrix
  Z <- Matrix::sparse.model.matrix(~as.factor(matdf[,"Treatments"]) - 1)
  Z <- as.matrix(Z)
  # Obtaining Rinv and Ginv matrix (and its inverse) for spatial analysis
  Rinv <- Matrix::drop0(Rinv)
  Ginv <- Matrix::drop0(Ginv)
  if(is.null(K)){
    # Obtaining X matrix
    if(nrow(matdf) == length(unique(matdf[,"Treatments"]))){
      X <- as.matrix(matdf[, "Reps"])
    }
    if(nrow(matdf) > length(unique(matdf[,"Treatments"]))){
      X <- Matrix::sparse.model.matrix(~as.factor(matdf[, "Reps"])-1)
    }
    # Obtaining C22 (only for Random Treatments)
    C11 <- Matrix::crossprod(as.matrix(X), as.matrix(Rinv)) %*% as.matrix(X)
    C11inv <- solve(C11)
    k1 <- Rinv %*% as.matrix(X)
    k2 <- Matrix::tcrossprod(as.matrix(C11inv), as.matrix(X))
    k3 <- k2 %*% Rinv
    K <- k1 %*% k3
    K <- Matrix(K, sparse = TRUE)
    temp0 <- Matrix::crossprod(Z, Rinv) %*% Z + Ginv - Matrix::crossprod(Z, K) %*% Z
  } else {
    temp0 <- t(Z) %*% Rinv %*% Z + Ginv - t(Z) %*% K %*% Z
  }
  C22 <- solve(temp0)
  C22 <- Matrix(C22, sparse = TRUE)  # This is the M(lambda) matrix
  # Calculating Optimum Criteria
  if(criteria == "A"){
    OptimScore <- sum(Matrix::diag(C22))
    return(list(OptimScore=OptimScore,K=K))
  }
  if(criteria == "D"){
    OptimScore <- log(Matrix::det(C22))
    return(list(OptimScore=OptimScore,K=K))
  }
}
